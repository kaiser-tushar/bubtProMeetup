<?php $__env->startSection('content'); ?>
<style type="text/css">
    .img-circle {
    border-radius: 50%;
    height: 200px; 
    width: 200px;
}
/*.btn-file{
    border: 0px;
}*/
</style>
    <!-- Header -->

    <!-- Contact Section -->
    <?php
         $path =public_path('img').'/'.'profile.png';
         $url = '/img/'.'profile.png';
        if(!empty($profile['photo_path'])){
            $path = public_path('img').'/users/'.$profile['photo_path'];
            $url = '/img/users/'.$profile['photo_path'];
        }
        
        if(!file_exists($path)){
              $path =public_path('img').'/'.'profile.png';
              $url = '/img/'.'profile.png';
        }
        // print_r($profile_data['photo_path']);die;
         ?>
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="row text-center">
                    <img class='img-circle' src='data:<?php echo e(mime_content_type($path)); ?>;base64,<?php echo e(base64_encode(file_get_contents($path))); ?>'/>
                </div>
                <div class="row control-group">
                     <div class="form-group">
                        <form action="<?php echo e(url('image-upload')); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-12 text-center">
                                   <label class="btn btn-xs btn-default btn-file">
                                        Change Profile Picture <input type="file" style="display: none;" name="image">
                                    </label>
                                    <button id="upload" type="submit" class="btn btn-success btn-xs" style="display: none;">Upload</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-12 text-center">
                    <h2><?php echo e($profile['name']); ?>'s PROFILE</h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                    <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>name: <?php echo e($profile['name']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                 <h5>email: <?php echo e($profile['email']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                               <h5>mobile: <?php echo e($profile['mobile']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                               <h5>present address: <?php echo e($profile['present_address']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>program: <?php echo e($educational_info['program']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>department: <?php echo e($educational_info['department']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>intake: <?php echo e($educational_info['intake']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>Student ID Card Number: <?php echo e($educational_info['student_id']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>Organization Name: <?php echo e($work['organization_name']); ?></h3>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <h5>Designation: <?php echo e($work['designation']); ?></h3>
                            </div>
                        </div>
                        <br>
                        <div id="success"></div>
                        <div class="row">
                            <div class="form-group col-xs-12">
                                <button type="button" id="edit" class="btn btn-success btn-lg">Edit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </section>
    <script type="text/javascript" src="/js/profile.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>