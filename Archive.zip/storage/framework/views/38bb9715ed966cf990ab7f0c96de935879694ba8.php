<?php $__env->startSection('contents'); ?>
    hello
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>