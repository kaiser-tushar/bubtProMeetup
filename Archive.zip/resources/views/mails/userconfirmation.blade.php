@extends('layouts.mail')

@section('contents')
    hello
@endsection
