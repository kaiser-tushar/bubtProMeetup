$(document).ready(function(){
	$('.btn-file').click(function(){
		$('#upload').show();
	});
})